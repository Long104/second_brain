<?php

session_start();

function calculateBMI($weight, $height) {

    if ($weight and $height > 0) {
      return  $weight/($height * $height);
    } else {
        echo "invalid";
    }

}

$bmi = "";
$name = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $weight = $_POST["weight"];
    $height = $_POST["height"];

    $bmi = calculateBMI($weight, $height);
    $_SESSION["name"] = $name;
    $_SESSION["bmi"] = $bmi;

}

$session_message = "";
if (isset($_SESSION["name"]) && isset($_SESSION["bmi"])) {
    $session_message = "Welcome back, " . $_SESSION["name"] . "! Last time your BMI was " . number_format($_SESSION["bmi"], 2) . ".";
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<style>
    body {

        font-family: Arial, sans-serif;
        margin: 20px;
    }
    .container {
        max-width: 60%;
        margin: auto;
    }
    h1 {
        color:#333;
    }
    form {
        margin-top: 20px;
    }
    input[type="text"] {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
    }
input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
        }
     .result {
            margin-top: 20px;
            padding: 10px;
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Interactive Birth Info & BMI Calculator</h1>
 
 
        <!-- Day of the Week and Zodiac Section (JavaScript) -->
        <section>
            <h2>Discover Your Birth Information</h2>
            <p>Enter your birthdate to find out the day of the week you were born and your zodiac sign.</p>
            <button onclick="getBirthInfo()">Click to Enter Your Birthdate</button>
            <p id="birthInfo"></p>
        </section>
 
 
        <!-- BMI Form (PHP Form Handling) -->
        <section>
            <h2>BMI Calculator</h2>
            <form method="POST" action="">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
 
 
                <label for="weight">Weight (in kg):</label>
                <input type="number" id="weight" name="weight" required>
 
 
                <label for="height">Height (in meters):</label>
                <input type="number" id="height" name="height" step="0.01" required>
 
 
                <input type="submit" value="Calculate BMI">
            </form>
 
 
            <?php if ($bmi): ?>
            <div class="result">
                <p><?php echo "Hello " . htmlspecialchars($name) . "! Your BMI is " . number_format($bmi, 2); ?>.</p>
                <p>
                    <?php 
                    if ($bmi < 18.5) {
                        echo "You are underweight. Make sure to have a balanced diet!";
                    } else if ($bmi < 24.9) {
                        echo "You have a normal weight. Keep up the good work!";
                    } elseif ($bmi < 29.9) {
                        echo "You are overweight. Consider incorporating more physical activity!";
                    } else {
                        echo "You are obese. It's a great time to focus on a healthier lifestyle!";
                    }
                    ?>
                </p>
            </div>
            <?php endif; ?>
        </section> 
 
        <!-- Returning User Message (PHP Session) -->
        <?php if ($session_message): ?>
        <section>
            <h3><?php echo $session_message; ?></h3>
        </section>
        <?php endif; ?>
    </div>
 
 
    <!-- JavaScript for Birth Info -->
    <script>
        function getBirthInfo() {
            let birthdate = prompt("Please enter your birthdate (YYYY-MM-DD):");
            if (birthdate) {
                 let date = new Date(birthdate);
                let options = { weekday: 'long' };
                let dayOfWeek = date.toLocaleDateString('en-US', options);
 
 
                let zodiacSign = getZodiacSign(date);
                let message = "You were born on a " + dayOfWeek + ". Your zodiac sign is " + zodiacSign.sign + ". " + zodiacSign.personality;
 
 
                document.getElementById("birthInfo").innerText = message;
            }
        }
 
 
        function getZodiacSign(date) {
            let day = date.getDate();
            let month = date.getMonth() + 1;
            let zodiacSigns = [
                { sign: "Capricorn", start: "12-22", end: "01-19", personality: "You are practical and disciplined. Stay focused!" },
                { sign: "Aquarius", start: "01-20", end: "02-18", personality: "You are independent and inventive. Keep embracing your originality!" },
                { sign: "Pisces", start: "02-19", end: "03-20", personality: "You are compassionate and artistic. Don't forget to nurture your creativity!" },
                { sign: "Aries", start: "03-21", end: "04-19", personality: "You are bold and ambitious. Take calculated risks and lead the way!" },
                { sign: "Taurus", start: "04-20", end: "05-20", personality: "You are reliable and patient. Keep striving towards your goals with perseverance!" },
                { sign: "Gemini", start: "05-21", end: "06-20", personality: "You are curious and adaptable. Keep learning and growing!" },
                { sign: "Cancer", start: "06-21", end: "07-22", personality: "You are nurturing and empathetic. Surround yourself with positive energy!" },
                { sign: "Leo", start: "07-23", end: "08-22", personality: "You are confident and energetic. Don't forget to take time to relax!" },
                { sign: "Virgo", start: "08-23", end: "09-22", personality: "You are analytical and kind. Your attention to detail will take you far!" },
                { sign: "Libra", start: "09-23", end: "10-22", personality: "You are balanced and charming. Keep fostering harmony in your life!" },
                { sign: "Scorpio", start: "10-23", end: "11-21", personality: "You are passionate and determined. Embrace your intensity and go after your dreams!" },
                { sign: "Sagittarius", start: "11-22", end: "12-21", personality: "You are optimistic and adventurous. Keep exploring the world and growing your horizons!" }
            ];
 
 
            for (let sign of zodiacSigns) {
               let startDate = new Date(date.getFullYear() + "-" + sign.start);
                let endDate = new Date(date.getFullYear() + "-" + sign.end);
 
 
                if ((month === startDate.getMonth() + 1 && day >= startDate.getDate()) ||
                    (month === endDate.getMonth() + 1 && day <= endDate.getDate())) {
                    return sign;
                }
            }
 
 
            return zodiacSigns[0];
        }
    </script>
</body>
</html>